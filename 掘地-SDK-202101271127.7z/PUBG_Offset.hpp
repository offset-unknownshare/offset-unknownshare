Actor	=	0x270,
BoneArry	=	0xB28,
ChunkSize	=	0x40E0,
ComponentToWorld	=	0x2B0,
GName	=	0x7812EE8,
GameInstence	=	0x248,
ItemClass	=	0xB8,
ItemID	=	0x248,
LocalPlayer	=	0x48,
PlayerController	=	0x48,
PlayerSatisitc	=	0x950,
PlayerState	=	0x438,
Uworld	=	0x78BEE28,
XeDecryption	=	0x66F0428,
// AActor	Type:struct FRepMovement
ReplicatedMovement	=	0x98,//(0x34)
// AActor	Type:class USceneComponent*
RootComponent	=	0x220,//(0x8)
// USceneComponent	Type:struct FRotator
RelativeRotation	=	0x30C,//(0xC)
// USceneComponent	Type:struct FVector
ComponentVelocity	=	0x348,//(0xC)
// UPrimitiveComponent	Type:float
LastRenderTimeOnScreen	=	0x7C0,//(0x4)
// AController	Type:class APawn*
Pawn	=	0x430,//(0x8)
// APlayerController	Type:class APlayerCameraManager*
PlayerCameraManager	=	0x4C0,//(0x8)
// USkeletalMeshComponent	Type:class UAnimInstance*
AnimScriptInstance	=	0xCD0,//(0x8)
// ACharacter	Type:class USkeletalMeshComponent*
Mesh	=	0x488,//(0x8)
// UCharacterMovementComponent	Type:float
MaxAcceleration	=	0x318,//(0x4)
// UCharacterMovementComponent	Type:struct FVector
Acceleration	=	0x3B8,//(0xC)
// UCharacterMovementComponent	Type:struct FVector
LastUpdateVelocity	=	0x3E0,//(0xC)
// APlayerCameraManager	Type:struct FCameraCacheEntry
CameraCache	=	0x460,//(0x5D0)
// APlayerCameraManager	Type:struct FTViewTarget
ViewTarget	=	0x1740,//(0x5E0)
// UWorld	Type:class ULevel*
CurrentLevel	=	0x798,//(0x8)
// Class:FMinimalViewInfo	Type:float
FOV	=	0x4,//(0x4)
// Class:FMinimalViewInfo	Type:struct FVector
Location	=	0x588,//(0xC)
// Class:FMinimalViewInfo	Type:struct FRotator
Rotation	=	0x5AC,//(0xC)
// UWeaponTrajectoryData	Type:struct FWeaponRecoilConfig
RecoilConfig	=	0x48,//(0xD8)
// UWeaponTrajectoryData	Type:struct FWeaponTrajectoryConfig
TrajectoryConfig	=	0x120,//(0x48)
// ATslWeapon_Trajectory	Type:float
TrajectoryGravityZ	=	0xEE0,//(0x4)
// ATslWeapon_Trajectory	Type:class UWeaponTrajectoryData*
WeaponTrajectoryData	=	0xFB8,//(0x8)
// ATslCharacter	Type:int
SpectatedCount	=	0xC40,//(0x4)
// ATslCharacter	Type:struct FString
CharacterName	=	0xDA0,//(0x10)
// ATslCharacter	Type:float
GroggyHealth	=	0xDE0,//(0x4)
// ATslCharacter	Type:float
Health	=	0xF04,//(0x4)
// ATslCharacter	Type:int
LastTeamNum	=	0xF88,//(0x4)
// ATslCharacter	Type:struct FRotator
AimOffsets	=	0x1320,//(0xC)
// ATslCharacter	Type:class UWeaponProcessorComponent*
WeaponProcessor	=	0x17A0,//(0x8)
// ATslCharacter	Type:class UVehicleRiderComponent*
VehicleRiderComponent	=	0x1858,//(0x8)
// UVehicleRiderComponent	Type:int
SeatIndex	=	0x238,//(0x4)
// UVehicleRiderComponent	Type:class APawn*
LastVehiclePawn	=	0x270,//(0x8)
// UWeaponProcessorComponent	Type:TArray<class ATslWeapon*>
EquippedWeapons	=	0x2C8,//(0x10)
// UWeaponProcessorComponent	Type:struct FWeaponArmInfo
WeaponArmInfo	=	0x2E8,//(0x5)
// UTslAnimInstance	Type:struct FRotator
ControlRotation_CP	=	0x6B0,//(0xC)
// UTslAnimInstance	Type:struct FRotator
RecoilADSRotation_CP	=	0x8DC,//(0xC)
// UTslAnimInstance	Type:float
RecoilRollValue_CP	=	0xB6C,//(0x4)
// UTslAnimInstance	Type:bool
bIsScoping_CP	=	0xBAD,//(0x1)
// UCrowdFollowingComponent	Type:class UCharacterMovementComponent*
CharacterMovement	=	0x4E0,//(0x8)
