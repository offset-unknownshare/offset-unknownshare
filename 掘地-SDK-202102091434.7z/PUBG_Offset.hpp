Actor	=	0x100,
BoneArry	=	0xB18,
ChunkSize	=	0x41C0,
ComponentToWorld	=	0x210,
GName	=	0x83E01D8,
GObject	=	0x82A1C00,
GameInstence	=	0x298,
ItemClass	=	0xB8,
ItemID	=	0x248,
LocalPlayer	=	0xE8,
PlayerController	=	0x48,
PlayerSatisitc	=	0x8FC,
PlayerState	=	0x440,
Uworld	=	0x8445E98,
XeDecryption	=	0x65AB328,
// USceneComponent	Type:struct FRotator
RelativeRotation	=	0x24C,//(0xC)
// USceneComponent	Type:struct FVector
ComponentVelocity	=	0x2F8,//(0xC)
// UPrimitiveComponent	Type:float
LastRenderTimeOnScreen	=	0x7B0,//(0x4)
// AActor	Type:struct FRepMovement
ReplicatedMovement	=	0x98,//(0x34)
// AActor	Type:class USceneComponent*
RootComponent	=	0x2C0,//(0x8)
// AController	Type:class APawn*
Pawn	=	0x428,//(0x8)
// APlayerController	Type:class APlayerCameraManager*
PlayerCameraManager	=	0x4C0,//(0x8)
// ACharacter	Type:class USkeletalMeshComponent*
Mesh	=	0x4D0,//(0x8)
// APlayerCameraManager	Type:struct FCameraCacheEntry
CameraCache	=	0x1050,//(0x5C0)
// APlayerCameraManager	Type:struct FTViewTarget
ViewTarget	=	0x16E0,//(0x5D0)
// UCharacterMovementComponent	Type:float
MaxAcceleration	=	0x318,//(0x4)
// UCharacterMovementComponent	Type:struct FVector
Acceleration	=	0x3B8,//(0xC)
// UCharacterMovementComponent	Type:struct FVector
LastUpdateVelocity	=	0x3E0,//(0xC)
// UWorld	Type:class ULevel*
CurrentLevel	=	0x370,//(0x8)
// USkeletalMeshComponent	Type:class UAnimInstance*
AnimScriptInstance	=	0xCC0,//(0x8)
// Class:FMinimalViewInfo	Type:struct FVector
Location	=	0xC,//(0xC)
// Class:FMinimalViewInfo	Type:struct FRotator
Rotation	=	0x1C,//(0xC)
// Class:FMinimalViewInfo	Type:float
FOV	=	0x3C,//(0x4)
// UTslAnimInstance	Type:struct FRotator
ControlRotation_CP	=	0x6C0,//(0xC)
// UTslAnimInstance	Type:struct FRotator
RecoilADSRotation_CP	=	0x8EC,//(0xC)
// UTslAnimInstance	Type:float
RecoilRollValue_CP	=	0xB7C,//(0x4)
// UTslAnimInstance	Type:bool
bIsScoping_CP	=	0xBBD,//(0x1)
// ATslCharacter	Type:class UWeaponProcessorComponent*
WeaponProcessor	=	0xCA8,//(0x8)
// ATslCharacter	Type:int
SpectatedCount	=	0xCB0,//(0x4)
// ATslCharacter	Type:struct FString
CharacterName	=	0xF10,//(0x10)
// ATslCharacter	Type:struct FRotator
AimOffsets	=	0x1410,//(0xC)
// ATslCharacter	Type:int
LastTeamNum	=	0x1788,//(0x4)
// ATslCharacter	Type:float
GroggyHealth	=	0x1848,//(0x4)
// ATslCharacter	Type:float
Health	=	0x18C4,//(0x4)
// ATslCharacter	Type:class UVehicleRiderComponent*
VehicleRiderComponent	=	0x1960,//(0x8)
// UWeaponTrajectoryData	Type:struct FWeaponRecoilConfig
RecoilConfig	=	0x48,//(0xD8)
// UWeaponTrajectoryData	Type:struct FWeaponTrajectoryConfig
TrajectoryConfig	=	0x120,//(0x48)
// ATslWeapon_Trajectory	Type:float
TrajectoryGravityZ	=	0xEF0,//(0x4)
// ATslWeapon_Trajectory	Type:class UWeaponTrajectoryData*
WeaponTrajectoryData	=	0xFE0,//(0x8)
// UWeaponProcessorComponent	Type:TArray<class ATslWeapon*>
EquippedWeapons	=	0x2C8,//(0x10)
// UWeaponProcessorComponent	Type:struct FWeaponArmInfo
WeaponArmInfo	=	0x2E8,//(0x5)
// UVehicleRiderComponent	Type:int
SeatIndex	=	0x238,//(0x4)
// UVehicleRiderComponent	Type:class APawn*
LastVehiclePawn	=	0x270,//(0x8)
// UCrowdFollowingComponent	Type:class UCharacterMovementComponent*
CharacterMovement	=	0x4E0,//(0x8)
